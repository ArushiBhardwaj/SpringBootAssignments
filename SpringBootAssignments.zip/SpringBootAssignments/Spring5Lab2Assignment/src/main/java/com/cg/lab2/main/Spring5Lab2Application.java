package com.cg.lab2.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring5Lab2Application {

	
	public static void main(String[] args) {
		SpringApplication.run(Spring5Lab2Application.class, args);
	}

}
