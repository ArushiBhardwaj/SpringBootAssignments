package com.cg.lab2.dao;

import java.util.List;

import com.cg.lab2.entity.Trainee;

public interface TraineeDao {
 void addTraineeDao(Trainee trainee);
 List<Trainee> findAll();
 Trainee findById(int id);
 void deleteById(int id);
 Trainee update(Trainee trainee, int traineeId);
 
}
