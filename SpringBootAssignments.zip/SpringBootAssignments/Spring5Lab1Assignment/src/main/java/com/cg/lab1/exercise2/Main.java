package com.cg.lab1.exercise2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("Beans.xml");
		Employee objA= (Employee) context.getBean("emp");
		System.out.println("Employee details");
		System.out.println("-----------------------");
		System.out.println(objA.getEmployeeId());
		System.out.println(objA.getEmployeeName());
		System.out.println(objA.getSalary());
		System.out.println(objA.getAge());
		System.out.println("SBU details");
		System.out.println(objA.getBusinessUnit().getSbuId());
		System.out.println(objA.getBusinessUnit().getSbuHead());
		System.out.println(objA.getBusinessUnit().getSbuName());

	}

}
